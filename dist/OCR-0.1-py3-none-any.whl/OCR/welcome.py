class Welcome:
    def say_welcome(self):
        print('say hello to my little friend! Maboooy')
        